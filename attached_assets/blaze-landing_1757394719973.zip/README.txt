Blaze Intelligence Landing Page
================================

Files:
- index.html
- styles.css
- app.js
- assets/logo.svg
- assets/founder.jpg (replace with your headshot)

Configuration:
- app.js uses BASE = https://blaze-vision-ai-gateway.humphrey-austin20.workers.dev
  Update BASE if your gateway domain changes.

Local test:
- Use any static server, e.g.:
  python3 -m http.server 8080

Deploy:
- Cloudflare Pages: drag the folder or connect repo
- Netlify/Vercel: static deploy, no build step required

Notes:
- "Connect stream" opens a WebSocket to /vision/session/:id/stream using a random demo session.
- Player Summary loads /vision/analytics/player/:id/summary and /trends.
- System section shows /healthz and /metrics.
- All calls are GET except session creation used for stream demo.
