
/* Blaze Intelligence Landing Runtime
   - Three.js hero animation
   - Live health + metrics from Cloudflare Worker
   - Player analytics sample + WebSocket demo for Grit Index
   Configure: BASE = your gateway origin
*/
const BASE = "https://blaze-vision-ai-gateway.humphrey-austin20.workers.dev";

// ---- Three.js Hero ----
async function initThree(){
  const [{Scene, PerspectiveCamera, WebGLRenderer, Color, Fog, SphereGeometry, ShaderMaterial, Points, AdditiveBlending, BufferAttribute, BufferGeometry, Vector3, Clock}, THREE] =
    await Promise.all([import('https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js'), null]);

  const canvas = document.getElementById('hero-canvas');
  const renderer = new WebGLRenderer({canvas, antialias:true, alpha:true});
  const scene = new Scene();
  scene.background = null;
  scene.fog = new Fog(new Color(0x0b0c10), 10, 120);
  const camera = new PerspectiveCamera(60, canvas.clientWidth/canvas.clientHeight, 0.1, 1000);
  camera.position.set(0, 0, 28);

  // Responsive
  function resize(){
    const w = canvas.clientWidth, h = 520;
    renderer.setSize(w, h, false);
    camera.aspect = w/h; camera.updateProjectionMatrix();
  }
  resize(); addEventListener('resize', resize);

  // Particle field
  const N = 4000;
  const positions = new Float32Array(N*3);
  const speeds = new Float32Array(N);
  for(let i=0;i<N;i++){
    positions[i*3+0] = (Math.random()-0.5)*60;
    positions[i*3+1] = (Math.random()-0.5)*30;
    positions[i*3+2] = (Math.random()-0.5)*40;
    speeds[i] = 0.04 + Math.random()*0.12;
  }
  const geom = new BufferGeometry();
  geom.setAttribute('position', new BufferAttribute(positions,3));
  geom.setAttribute('speed', new BufferAttribute(speeds,1));
  const mat = new ShaderMaterial({
    transparent:true, blending:AdditiveBlending, depthWrite:false,
    uniforms:{ uTime:{value:0.0}, uColorA:{value:{r:1,g:0.36,b:0}}, uColorB:{value:{r:1,g:0.69,b:0}} },
    vertexShader:`
      uniform float uTime; attribute float speed; varying float vAlpha;
      void main(){
        vec3 p = position;
        p.x += sin(uTime*speed + p.z*0.05)*0.6;
        p.y += cos(uTime*speed*1.2 + p.x*0.05)*0.4;
        vAlpha = 0.35 + 0.65*fract(speed*2.0);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p,1.0);
        gl_PointSize = 1.0 + 2.5*speed;
      }`,
    fragmentShader:`
      precision mediump float; varying float vAlpha;
      void main(){ gl_FragColor = vec4(1.0,0.48,0.0, vAlpha); }`
  });
  const pts = new Points(geom, mat);
  scene.add(pts);

  const clock = new Clock();
  (function loop(){
    mat.uniforms.uTime.value += clock.getDelta();
    renderer.render(scene, camera);
    requestAnimationFrame(loop);
  })();
}

// ---- Data helpers ----
async function safeJSON(url, init){
  try{
    const res = await fetch(url, init);
    if(!res.ok) throw new Error(res.status + " " + res.statusText);
    return await res.json();
  }catch(e){ console.warn("fetch fail", url, e); return null; }
}

// Populate system status
async function loadSystem(){
  const el = (id)=>document.getElementById(id);
  const health = await fetch(`${BASE}/healthz`).then(r=>r.text()).catch(()=>null);
  el("health-text").textContent = health || "unknown";
  el("health-badge").className = "badge " + (health && /ok|healthy|pass/i.test(health) ? "ok":"warn");

  const stats = await safeJSON(`${BASE}/vision/analytics/system/stats`);
  if(stats){
    el("kpi-latency").textContent = (stats.gateway_latency_ms ?? 0).toFixed(0) + " ms";
    el("kpi-telemetry").textContent = (stats.telemetry_p95_ms ?? 0).toFixed(0) + " ms";
    el("kpi-sessions").textContent = stats.active_sessions ?? 0;
    el("kpi-qps").textContent = (stats.ingest_qps ?? 0).toFixed(1);
  }
  const metrics = await fetch(`${BASE}/metrics`).then(r=>r.text()).catch(()=>null);
  document.getElementById("metrics-pre").textContent = metrics ? metrics.slice(0, 2000) : "no metrics";
}

// Demo player analytics
async function loadPlayer(){
  const id = (document.getElementById("player-id").value || "test_player").trim();
  const summary = await safeJSON(`${BASE}/vision/analytics/player/${encodeURIComponent(id)}/summary`);
  const trends = await safeJSON(`${BASE}/vision/analytics/player/${encodeURIComponent(id)}/trends`);
  const sEl = document.getElementById("player-summary");
  sEl.innerHTML = "";
  if(summary){
    const items = [
      ["Grit Index", summary.grit_index?.toFixed?.(2)],
      ["Pressure Response", summary.pressure_response?.toFixed?.(2)],
      ["Momentum", summary.momentum_creation?.toFixed?.(2)],
      ["Adversity Recovery", summary.adversity_recovery?.toFixed?.(2)],
    ];
    for(const [k,v] of items){
      const div = document.createElement("div");
      div.className = "kpi"; div.innerHTML = `<div class="label">${k}</div><div class="value">${v ?? "—"}</div>`;
      sEl.appendChild(div);
    }
  } else {
    sEl.innerHTML = `<div class="kpi"><div class="label">No data</div><div class="value">—</div></div>`;
  }
  const tEl = document.getElementById("trend-pre");
  if(trends){ tEl.textContent = JSON.stringify(trends, null, 2).slice(0, 2000); }
  else { tEl.textContent = "no trend data"; }
}

// Live stream demo
let ws;
function connectStream(){
  const sessionId = "demo-" + Math.random().toString(36).slice(2,8);
  // Create session for stream-friendly demo
  fetch(`${BASE}/vision/sessions`, {method:"POST", headers:{'Content-Type':'application/json', 'X-Dev-Mode':'true'}, body:JSON.stringify({session_id:sessionId, player_id:"test_player", sport:"baseball"})}).catch(()=>{});
  const url = `${BASE.replace("https://","wss://")}/vision/session/${sessionId}/stream`;
  ws = new WebSocket(url);
  const out = document.getElementById("ws-pre");
  ws.onopen = ()=>{ out.textContent = "connected: " + url; };
  ws.onmessage = (ev)=>{
    try{
      const msg = JSON.parse(ev.data);
      if(msg?.scores?.grit_index){
        document.getElementById("live-grit").textContent = msg.scores.grit_index.toFixed(2);
      }
      out.textContent = ev.data.slice(0, 1800);
    }catch{ out.textContent = ev.data.slice(0, 1800); }
  };
  ws.onclose = ()=>{ out.textContent += "\nclosed"; };
}

document.addEventListener("DOMContentLoaded", ()=>{
  initThree();
  loadSystem();
  document.getElementById("btn-refresh").addEventListener("click", loadSystem);
  document.getElementById("btn-player").addEventListener("click", loadPlayer);
  document.getElementById("btn-stream").addEventListener("click", connectStream);
});
