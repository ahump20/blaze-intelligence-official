// Main client script for Blaze Intelligence landing page
// Provides: Three.js hero animation, health & metrics fetch, player analytics, and live streaming demo.

// Base URL for the Blaze Vision AI gateway. Update this if your production endpoint changes.
const BASE = "https://blaze-vision-ai-gateway.humphrey-austin20.workers.dev";

// --- Helper functions ---
// Safe JSON helper to fetch and parse JSON responses with graceful error handling.
async function safeJSON(url, init) {
  try {
    const res = await fetch(url, init);
    if (!res.ok) throw new Error(res.status + " " + res.statusText);
    return await res.json();
  } catch (err) {
    console.warn("Failed to fetch", url, err);
    return null;
  }
}

// Load system status and performance KPIs
async function loadSystem() {
  // Elements for system status
  const badge = document.getElementById("health-badge");
  const text = document.getElementById("health-text");
  const latency = document.getElementById("kpi-latency");
  const telem = document.getElementById("kpi-telemetry");
  const sessions = document.getElementById("kpi-sessions");
  const qps = document.getElementById("kpi-qps");

  try {
    // healthz returns a plain‑text status string
    const health = await fetch(`${BASE}/healthz`).then((r) => r.text());
    text.textContent = health || "unknown";
    if (health && /ok|healthy|pass/i.test(health)) {
      badge.className = "badge ok";
    } else {
      badge.className = "badge warn";
    }
  } catch {
    text.textContent = "unreachable";
    badge.className = "badge bad";
  }

  // Load system stats JSON
  const stats = await safeJSON(`${BASE}/vision/analytics/system/stats`);
  if (stats) {
    latency.textContent = (stats.gateway_latency_ms ?? 0).toFixed(0) + " ms";
    telem.textContent = (stats.telemetry_p95_ms ?? 0).toFixed(0) + " ms";
    sessions.textContent = stats.active_sessions ?? 0;
    qps.textContent = (stats.ingest_qps ?? 0).toFixed(1);
  }
  // Load raw metrics from /metrics and display first 2k chars
  try {
    const metrics = await fetch(`${BASE}/metrics`).then((r) => r.text());
    document.getElementById("metrics-pre").textContent = metrics
      ? metrics.slice(0, 2000)
      : "no metrics";
  } catch {
    document.getElementById("metrics-pre").textContent = "metrics unavailable";
  }
}

// Load per‑player analytics for a given player id
async function loadPlayer() {
  const idField = document.getElementById("player-id");
  const playerId = (idField.value || "test_player").trim();
  const summaryEl = document.getElementById("player-summary");
  const trendEl = document.getElementById("trend-pre");
  summaryEl.innerHTML = "";
  trendEl.textContent = "loading…";

  // Summary endpoint
  const summary = await safeJSON(
    `${BASE}/vision/analytics/player/${encodeURIComponent(playerId)}/summary`
  );
  if (summary) {
    const items = [
      ["Grit Index", summary.grit_index?.toFixed?.(2)],
      ["Pressure Response", summary.pressure_response?.toFixed?.(2)],
      ["Momentum", summary.momentum_creation?.toFixed?.(2)],
      ["Adversity Recovery", summary.adversity_recovery?.toFixed?.(2)],
    ];
    for (const [label, value] of items) {
      const div = document.createElement("div");
      div.className = "kpi";
      div.innerHTML = `<div class="label">${label}</div><div class="value">${
        value ?? "—"
      }</div>`;
      summaryEl.appendChild(div);
    }
  } else {
    summaryEl.innerHTML = `<div class="kpi"><div class="label">No data</div><div class="value">—</div></div>`;
  }

  // Trend endpoint
  const trends = await safeJSON(
    `${BASE}/vision/analytics/player/${encodeURIComponent(playerId)}/trends`
  );
  trendEl.textContent = trends
    ? JSON.stringify(trends, null, 2).slice(0, 2000)
    : "no trend data";
}

// Connect to live stream of a random session to demonstrate real‑time Grit Index updates
let ws;
function connectStream() {
  // Create a short random session id for demonstration
  const sessionId = "demo-" + Math.random().toString(36).slice(2, 8);
  // Precreate session so the stream exists. Use X-Dev-Mode to avoid quotas.
  fetch(`${BASE}/vision/sessions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Dev-Mode": "true",
    },
    body: JSON.stringify({ session_id: sessionId, player_id: "test_player", sport: "baseball" }),
  }).catch(() => {});
  // Form WebSocket URL (replace https:// with wss://)
  const wsUrl = `${BASE.replace("https://", "wss://")}/vision/session/${sessionId}/stream`;
  ws = new WebSocket(wsUrl);
  const out = document.getElementById("ws-pre");
  out.textContent = "connecting…";
  ws.onopen = () => {
    out.textContent = "connected: " + wsUrl;
  };
  ws.onmessage = (ev) => {
    try {
      const msg = JSON.parse(ev.data);
      if (msg?.scores?.grit_index) {
        const val = msg.scores.grit_index;
        document.getElementById("live-grit").textContent = val.toFixed(2);
      }
      out.textContent = ev.data.slice(0, 1800);
    } catch {
      out.textContent = ev.data.slice(0, 1800);
    }
  };
  ws.onclose = () => {
    out.textContent += "\nclosed";
  };
}

// Initialize Three.js hero particle animation
async function initThree() {
  // Dynamically import Three.js module (ES module version)
  const THREE = await import(
    /* webpackIgnore: true */ "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js"
  );
  const {
    Scene,
    PerspectiveCamera,
    WebGLRenderer,
    Color,
    Fog,
    BufferGeometry,
    BufferAttribute,
    ShaderMaterial,
    Points,
    AdditiveBlending,
    Clock,
  } = THREE;
  const canvas = document.getElementById("hero-canvas");
  const renderer = new WebGLRenderer({ canvas, antialias: true, alpha: true });
  const scene = new Scene();
  scene.background = null;
  scene.fog = new Fog(new Color(0x0b0c10), 10, 120);
  const camera = new PerspectiveCamera(
    60,
    canvas.clientWidth / canvas.clientHeight,
    0.1,
    1000
  );
  camera.position.set(0, 0, 28);
  // Resize handler
  function resize() {
    const w = canvas.clientWidth;
    const h = 520;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  window.addEventListener("resize", resize);
  // Create particle field
  const N = 4000;
  const positions = new Float32Array(N * 3);
  const speeds = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    positions[i * 3 + 0] = (Math.random() - 0.5) * 60;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 30;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 40;
    speeds[i] = 0.04 + Math.random() * 0.12;
  }
  const geometry = new BufferGeometry();
  geometry.setAttribute("position", new BufferAttribute(positions, 3));
  geometry.setAttribute("speed", new BufferAttribute(speeds, 1));
  const material = new ShaderMaterial({
    transparent: true,
    blending: AdditiveBlending,
    depthWrite: false,
    uniforms: {
      uTime: { value: 0.0 },
    },
    vertexShader: `
      uniform float uTime;
      attribute float speed;
      varying float vAlpha;
      void main() {
        vec3 p = position;
        p.x += sin(uTime * speed + p.z * 0.05) * 0.6;
        p.y += cos(uTime * speed * 1.2 + p.x * 0.05) * 0.4;
        vAlpha = 0.35 + 0.65 * fract(speed * 2.0);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = 1.0 + 2.5 * speed;
      }`,
    fragmentShader: `
      precision mediump float;
      varying float vAlpha;
      void main() {
        // Orange gradient points
        gl_FragColor = vec4(1.0, 0.48, 0.0, vAlpha);
      }`,
  });
  const points = new Points(geometry, material);
  scene.add(points);
  const clock = new Clock();
  function animate() {
    material.uniforms.uTime.value += clock.getDelta();
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();
}

// Initialize everything when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  initThree();
  loadSystem();
  document.getElementById("btn-refresh").addEventListener("click", loadSystem);
  document.getElementById("btn-player").addEventListener("click", loadPlayer);
  document.getElementById("btn-stream").addEventListener("click", connectStream);
  // Initialize the sports dashboard for real‑time team & player stats.
  initDashboard();
});

// ----- Sports Dashboard Implementation -----

// Cache for teams and players to reduce API calls
const TEAM_CACHE = {};
const PLAYER_CACHE = {};

// Populate the team select dropdown based on chosen sport
async function populateTeams() {
  const sport = document.getElementById("sport-select").value;
  const teamSelect = document.getElementById("team-select");
  teamSelect.innerHTML = "";
  let teams = TEAM_CACHE[sport];
  if (!teams) {
    if (sport === "mlb") {
      teams = await fetchMLBTeams();
    } else if (sport === "nba") {
      teams = await fetchNBATeams();
    } else {
      teams = await fetchNFLTeams();
    }
    TEAM_CACHE[sport] = teams;
  }
  for (const team of teams) {
    const opt = document.createElement("option");
    opt.value = team.id;
    opt.textContent = team.name;
    teamSelect.appendChild(opt);
  }
  // Auto-populate players for the first team
  populatePlayers();
}

// Populate player dropdown based on selected team (MLB only for now)
async function populatePlayers() {
  const sport = document.getElementById("sport-select").value;
  const playerSelect = document.getElementById("player-select");
  playerSelect.innerHTML = "";
  if (sport !== "mlb") {
    // Hide player select for sports without player stats implemented
    playerSelect.style.display = "none";
    return;
  }
  playerSelect.style.display = "";
  const teamId = document.getElementById("team-select").value;
  const cacheKey = `mlb-${teamId}`;
  let players = PLAYER_CACHE[cacheKey];
  if (!players) {
    players = await fetchMLBPlayers(teamId);
    PLAYER_CACHE[cacheKey] = players;
  }
  const emptyOpt = document.createElement("option");
  emptyOpt.value = "";
  emptyOpt.textContent = "--";
  playerSelect.appendChild(emptyOpt);
  for (const player of players) {
    const opt = document.createElement("option");
    opt.value = player.id;
    opt.textContent = player.name;
    playerSelect.appendChild(opt);
  }
}

// Initialize the dashboard by attaching event listeners and populating teams
function initDashboard() {
  document.getElementById("sport-select").addEventListener("change", () => {
    populateTeams();
  });
  document.getElementById("team-select").addEventListener("change", () => {
    populatePlayers();
  });
  document.getElementById("btn-team-load").addEventListener("click", () => {
    loadTeamData();
  });
  // Populate initial selections
  populateTeams();
}

// Fetch list of MLB teams from StatsAPI
async function fetchMLBTeams() {
  const data = await safeJSON("https://statsapi.mlb.com/api/v1/teams?sportId=1");
  if (!data || !data.teams) return [];
  return data.teams.map((t) => ({
    id: t.id.toString(),
    name: t.name,
  }));
}

// Fetch list of MLB players for a team
async function fetchMLBPlayers(teamId) {
  if (!teamId) return [];
  const roster = await safeJSON(
    `https://statsapi.mlb.com/api/v1/teams/${teamId}/roster`
  );
  if (!roster || !roster.roster) return [];
  return roster.roster.map((p) => ({
    id: p.person.id.toString(),
    name: p.person.fullName,
  }));
}

// Fetch list of NBA teams from BallDontLie API
async function fetchNBATeams() {
  const data = await safeJSON("https://www.balldontlie.io/api/v1/teams");
  if (!data || !data.data) return [];
  return data.data.map((t) => ({
    id: t.id.toString(),
    name: t.full_name,
  }));
}

// Fetch list of NFL teams from ESPN scoreboard (use team abbreviation + id)
async function fetchNFLTeams() {
  // ESPN scoreboard returns week schedule; but team info repeated; compile unique teams
  const data = await safeJSON(
    `https://site.api.espn.com/apis/v2/sports/football/nfl/teams`
  );
  if (!data || !data.sports || !data.sports[0]?.leagues[0]?.teams) return [];
  const teamsRaw = data.sports[0].leagues[0].teams;
  return teamsRaw.map((item) => ({
    id: item.team.id.toString(),
    name: item.team.displayName,
  }));
}

// Load data for the selected sport/team/player
async function loadTeamData() {
  const sport = document.getElementById("sport-select").value;
  const teamId = document.getElementById("team-select").value;
  const playerId = document.getElementById("player-select").value || null;
  if (!teamId) return;
  if (sport === "mlb") {
    await loadMLBTeamData(teamId);
    if (playerId) {
      await loadPlayerStatsDashboard(playerId);
    }
  } else if (sport === "nba") {
    await loadNBATeamData(teamId);
  } else {
    await loadNFLTeamData(teamId);
  }
}

// Helper to compute EWMA projection for next game runs/points
function computeEWMA(values, alpha = 0.5) {
  let prev = values[0];
  for (let i = 1; i < values.length; i++) {
    prev = alpha * values[i] + (1 - alpha) * prev;
  }
  return prev;
}

// Load MLB team record, recent games, next game, and projection
async function loadMLBTeamData(teamId) {
  const teamInfoEl = document.getElementById("team-info");
  const teamNameEl = document.getElementById("team-name");
  const teamRecordEl = document.getElementById("team-record");
  const lastGamesEl = document.getElementById("team-last-games");
  const nextGameEl = document.getElementById("team-next-game");
  const projEl = document.getElementById("team-projection");
  teamInfoEl.style.display = "block";
  const schedule = await safeJSON(
    `https://statsapi.mlb.com/api/v1/schedule?teamId=${teamId}&season=${new Date().getFullYear()}`
  );
  if (!schedule || !schedule.dates) {
    teamNameEl.textContent = "Unknown team";
    teamRecordEl.textContent = "";
    lastGamesEl.textContent = "";
    nextGameEl.textContent = "";
    projEl.textContent = "";
    return;
  }
  // Find team name from first date
  const sample = schedule.dates[0]?.games?.find((g) => g.teams?.away?.team?.id == teamId || g.teams?.home?.team?.id == teamId);
  if (sample) {
    const teamObj = sample.teams.away.team.id == teamId ? sample.teams.away.team : sample.teams.home.team;
    teamNameEl.textContent = teamObj.name;
  } else {
    teamNameEl.textContent = "";
  }
  // Compute record by iterating games
  let wins = 0, losses = 0;
  const scores = [];
  const gamesFlat = [];
  for (const d of schedule.dates) {
    for (const g of d.games) {
      gamesFlat.push(g);
    }
  }
  // Sort games by date ascending
  gamesFlat.sort((a,b) => new Date(a.gameDate) - new Date(b.gameDate));
  for (const game of gamesFlat) {
    const isHome = game.teams.home.team.id == teamId;
    const teamScore = isHome ? game.teams.home.score : game.teams.away.score;
    const oppScore = isHome ? game.teams.away.score : game.teams.home.score;
    if (teamScore != null && oppScore != null) {
      scores.push(teamScore);
      if (teamScore > oppScore) wins++; else losses++;
    }
  }
  teamRecordEl.textContent = `Record: ${wins}-${losses}`;
  // Last 5 games results
  const last5 = gamesFlat.slice(-5);
  let lastTxt = "";
  for (const g of last5) {
    const isHome = g.teams.home.team.id == teamId;
    const tScore = isHome ? g.teams.home.score : g.teams.away.score;
    const oScore = isHome ? g.teams.away.score : g.teams.home.score;
    const result = tScore > oScore ? "W" : "L";
    const opp = isHome ? g.teams.away.team.name : g.teams.home.team.name;
    const date = new Date(g.gameDate).toLocaleDateString();
    lastTxt += `${date}: ${result} vs ${opp} (${tScore}-${oScore})\n`;
  }
  lastGamesEl.textContent = lastTxt;
  // Next game
  const upcoming = gamesFlat.find((g) => g.status?.statusCode === "S");
  if (upcoming) {
    const vsTeam = upcoming.teams.away.team.id == teamId ? upcoming.teams.home.team.name : upcoming.teams.away.team.name;
    const nextDate = new Date(upcoming.gameDate).toLocaleString();
    nextGameEl.textContent = `Next: vs ${vsTeam} on ${nextDate}`;
  } else {
    nextGameEl.textContent = "No upcoming game";
  }
  // Projection using EWMA of last 5 completed games
  const recentScores = scores.slice(-5);
  if (recentScores.length >= 2) {
    const proj = computeEWMA(recentScores);
    projEl.textContent = `Projected runs next game: ${proj.toFixed(1)}`;
  } else {
    projEl.textContent = "";
  }
}

// Load MLB player hitting stats for season
async function loadPlayerStatsDashboard(playerId) {
  const playerInfoEl = document.getElementById("player-info");
  const playerNameEl = document.getElementById("player-name");
  const playerStatsEl = document.getElementById("player-stats");
  playerInfoEl.style.display = "block";
  const data = await safeJSON(
    `https://statsapi.mlb.com/api/v1/people/${playerId}/stats?stats=season&group=hitting`
  );
  if (!data || !data.stats || !data.stats[0]?.splits?.[0]) {
    playerNameEl.textContent = "Player";
    playerStatsEl.textContent = "No data";
    return;
  }
  const split = data.stats[0].splits[0];
  playerNameEl.textContent = split.player?.fullName || "Player";
  const stat = split.stat;
  playerStatsEl.innerHTML = `\n    AVG: ${stat.avg ?? "—"}<br>\n    HR: ${stat.homeRuns ?? "—"}<br>\n    RBI: ${stat.rbi ?? "—"}<br>\n    OPS: ${stat.ops ?? "—"}\n  `;
}

// Load NBA team data: record and last games using BallDontLie API
async function loadNBATeamData(teamId) {
  const teamInfoEl = document.getElementById("team-info");
  const teamNameEl = document.getElementById("team-name");
  const teamRecordEl = document.getElementById("team-record");
  const lastGamesEl = document.getElementById("team-last-games");
  const nextGameEl = document.getElementById("team-next-game");
  const projEl = document.getElementById("team-projection");
  teamInfoEl.style.display = "block";
  // Fetch team info
  const teamData = await safeJSON(
    `https://www.balldontlie.io/api/v1/teams/${teamId}`
  );
  if (!teamData) {
    teamNameEl.textContent = "Team";
    teamRecordEl.textContent = "";
    lastGamesEl.textContent = "";
    nextGameEl.textContent = "";
    projEl.textContent = "";
    return;
  }
  teamNameEl.textContent = teamData.full_name;
  // Fetch last 12 games to compute record & projection
  const games = await safeJSON(
    `https://www.balldontlie.io/api/v1/games?team_ids[]=${teamId}&per_page=12`
  );
  if (!games || !games.data) {
    teamRecordEl.textContent = "";
    lastGamesEl.textContent = "";
    nextGameEl.textContent = "";
    projEl.textContent = "";
    return;
  }
  const recent = games.data;
  // compute wins and losses
  let wins = 0, losses = 0;
  const scores = [];
  for (const game of recent) {
    const isHome = game.home_team.id == teamId;
    const tScore = isHome ? game.home_team_score : game.visitor_team_score;
    const oScore = isHome ? game.visitor_team_score : game.home_team_score;
    scores.push(tScore);
    if (tScore > oScore) wins++; else losses++;
  }
  teamRecordEl.textContent = `Record (last ${recent.length}): ${wins}-${losses}`;
  // Last 5 games details
  let lastTxt = "";
  const last5 = recent.slice(0,5);
  for (const g of last5) {
    const isHome = g.home_team.id == teamId;
    const tScore = isHome ? g.home_team_score : g.visitor_team_score;
    const oScore = isHome ? g.visitor_team_score : g.home_team_score;
    const result = tScore > oScore ? "W" : "L";
    const opp = isHome ? g.visitor_team.full_name : g.home_team.full_name;
    const date = new Date(g.date).toLocaleDateString();
    lastTxt += `${date}: ${result} vs ${opp} (${tScore}-${oScore})\n`;
  }
  lastGamesEl.textContent = lastTxt;
  // Next game - BallDontLie doesn't have schedule; show placeholder
  nextGameEl.textContent = "Next game data not available via API";
  // Projection using EWMA
  if (scores.length >= 2) {
    const proj = computeEWMA(scores.slice(0,5));
    projEl.textContent = `Projected points next game: ${proj.toFixed(1)}`;
  } else {
    projEl.textContent = "";
  }
}

// Load NFL team data via ESPN scoreboard
async function loadNFLTeamData(teamId) {
  const teamInfoEl = document.getElementById("team-info");
  const teamNameEl = document.getElementById("team-name");
  const teamRecordEl = document.getElementById("team-record");
  const lastGamesEl = document.getElementById("team-last-games");
  const nextGameEl = document.getElementById("team-next-game");
  const projEl = document.getElementById("team-projection");
  teamInfoEl.style.display = "block";
  // ESPN team details endpoint
  const teamData = await safeJSON(
    `https://site.api.espn.com/apis/v2/sports/football/nfl/teams/${teamId}`
  );
  if (!teamData || !teamData.team) {
    teamNameEl.textContent = "Team";
    teamRecordEl.textContent = "";
    lastGamesEl.textContent = "";
    nextGameEl.textContent = "";
    projEl.textContent = "";
    return;
  }
  const team = teamData.team;
  teamNameEl.textContent = team.displayName || team.name;
  // Record (if available)
  if (team.record?.items?.length) {
    const record = team.record.items[0];
    teamRecordEl.textContent = `Record: ${record.summary}`;
  } else {
    teamRecordEl.textContent = "";
  }
  // ESPN scoreboard uses events to list schedule; fetch recent 10 events
  const events = await safeJSON(
    `https://site.api.espn.com/apis/v2/sports/football/nfl/teams/${teamId}/schedule?limit=10`
  );
  if (!events || !events.events) {
    lastGamesEl.textContent = "";
    nextGameEl.textContent = "";
    projEl.textContent = "";
    return;
  }
  const games = events.events;
  // separate past and future
  const past = [];
  const future = [];
  const now = Date.now();
  for (const ev of games) {
    const dateMs = new Date(ev.date).getTime();
    if (dateMs < now) past.push(ev); else future.push(ev);
  }
  // Sort past by date descending
  past.sort((a,b) => new Date(b.date) - new Date(a.date));
  // Last 5
  let lastTxt = "";
  for (const ev of past.slice(0,5)) {
    const opp = ev.competitions?.[0]?.competitors?.find((c) => c.id != teamId);
    const tScore = ev.competitions?.[0]?.competitors?.find((c) => c.id == teamId)?.score;
    const oScore = opp?.score;
    const result = tScore > oScore ? "W" : "L";
    const date = new Date(ev.date).toLocaleDateString();
    lastTxt += `${date}: ${result} vs ${opp?.team?.displayName ?? ""} (${tScore}-${oScore})\n`;
  }
  lastGamesEl.textContent = lastTxt;
  // Next game
  if (future.length) {
    const next = future[0];
    const opp = next.competitions?.[0]?.competitors?.find((c) => c.id != teamId);
    const date = new Date(next.date).toLocaleString();
    nextGameEl.textContent = `Next: vs ${opp?.team?.displayName ?? ""} on ${date}`;
  } else {
    nextGameEl.textContent = "No upcoming game";
  }
  // Projection using EWMA of past team points
  const scores = [];
  for (const ev of past) {
    const tScore = ev.competitions?.[0]?.competitors?.find((c) => c.id == teamId)?.score;
    if (tScore != null) scores.push(parseInt(tScore));
  }
  if (scores.length >= 2) {
    const proj = computeEWMA(scores.slice(0,5));
    projEl.textContent = `Projected points next game: ${proj.toFixed(1)}`;
  } else {
    projEl.textContent = "";
  }
}